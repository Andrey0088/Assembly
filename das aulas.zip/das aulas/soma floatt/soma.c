#include <stdio.h>
float a,b,c;
int main()
{
    printf("Entre com um float: ");
    scanf("%f",&a);

    printf("Entre com outro float: ");
    scanf("%f",&a);
    c= a+b;
    printf("A soma dos dois floats eh: %f /n",c);

}
