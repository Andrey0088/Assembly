int main();

int main() {
	register int num1 = 30
	register int num2 = 70
	register int num3 = 99
	int soma = ((num1 + num2)-num3)+num1;
	return 0;
}